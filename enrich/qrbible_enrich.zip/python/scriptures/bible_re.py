from .texts.protestant import ProtestantCanon

# create an instance of the Protestant Canon to use as the default
pcanon=ProtestantCanon()

book_re = pcanon.book_re
scripture_re = pcanon.scripture_re

