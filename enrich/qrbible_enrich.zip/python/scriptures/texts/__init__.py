from .base import InvalidReferenceException
